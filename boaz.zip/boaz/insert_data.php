<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "submit";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Prepare and bind the insert statement
$stmt = $conn->prepare("INSERT INTO  application_form(firstName, lastName, gender, email, dob, address) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssss", $firstName, $lastName, $gender, $email, $dob, $address);

// Retrieve the form data
$firstName = $_POST["firstName"];
$lastName = $_POST["lastName"];
$gender = $_POST["gender"];
$email = $_POST["email"];
$dob = $_POST["dob"];
$address = $_POST["address"];

// Execute the insert statement
$stmt->execute();

echo "New record created successfully";

$stmt->close();
$conn->close();
