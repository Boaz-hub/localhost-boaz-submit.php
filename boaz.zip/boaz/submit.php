<!DOCTYPE html>
<html>
  <head>
  </head>
  <body>
    <h1>Application form</h1>
    <form method="POST" action="insert_data.php">
      <label for="firstName">First Name:</label>
      <br>
      <input type="text" name="firstName" id="firstName" required>
      <br>

      <label for="lastName">Last Name:</label>
      <br>
      <input type="text" name="lastName" id="lastName" required>
      <br>

      <label for="gender">Gender:</label>
      <br>
      <select name="gender" id="gender" required>
        <option value="">Please select</option>
        <option value="male">Male</option>
        <option value="female">Female</option>
        <option value="other">Other</option>
      </select>
      <br>

      <label for="email">Email:</label>
      <br>
      <input type="email" name="email" id="email" required>
      <br>

      <label for="dob">Date of Birth:</label>
      <br>
      <input type="date" name="dob" id="dob" required>
      <br>

      <label for="address">Address:</label>
      <br>
      <textarea name="address" id="address" rows="4" cols="50" required></textarea>
      <br>

      <button type="submit">Submit</button>
    </form>
  </body>
</html>